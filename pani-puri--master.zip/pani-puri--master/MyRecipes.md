puri recipe for pani puri:

1.firstly, in a large bowl take 1 cup rava and 2 tbsp maida. 2.add 3 tbsp oil, crumble and mix well making sure the rava turns moist. 3.now add ¼ cup hot water and start to knead. 4.knead for 5 to 8 minutes or until the dough is formed. 5.sprinkle water as required and knead to a smooth and soft dough. 6.cover the dough and rest for 20 minutes. 7.after 20 minutes, continue to knead for 2 more minutes. 8.now pinch a very small ball sized dough. 9.roll and flatten into small disk making sure it is thin. 10.deep fry in hot oil, do not overcrowd the oil. 11.flip over once the puri puffs up. 12.fry on medium flame until it turns golden brown and crisp from both the sides. 13.drain off over kitchen paper to get rid off excess oil. 14.puri is ready for pani puri. once cooled completely, you can store in an airtight container and use it for a week.

theeka pani preparation:

1.firstly, in a small blender take ¼ cup mint, ½ cup coriander, 1 inch ginger, 2 chilli and small ball sized tamarind.

2.blend to smooth paste adding water as required. 3.transfer theeka pani puri paste into a large bowl. 4.add 1 tsp chaat masala, 1 tsp cumin powder, pinch hing, ¾ tsp salt and 4 cup cold water. 5.mix well and theeka pani is ready to enjoy with golgappa.

aloo stuffing preparation:

1.firstly, in a small bowl take 3 potato, ½ onion and 2 tbsp coriander. 2.also add ½ tsp cumin powder, ½ tsp chaat masala, ¼ tsp pepper powder, ½ tsp chilli powder and ½ tsp salt.

3.mix well making sure everything is well combined. 4.aloo stuffing is ready to enjoy with puchka.